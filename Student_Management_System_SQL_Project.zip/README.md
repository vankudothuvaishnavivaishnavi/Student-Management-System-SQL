# Student Management System SQL Project

This project includes:
- Database creation
- Students, Courses, Enrollments tables
- Sample records
- Primary & Foreign Keys
- SELECT, WHERE, ORDER BY, GROUP BY
- JOIN, UPDATE, DELETE queries
