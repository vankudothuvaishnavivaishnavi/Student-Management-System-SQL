-- Student Management System Database Project

CREATE DATABASE StudentManagementSystem;
USE StudentManagementSystem;

CREATE TABLE Students (
    StudentID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Gender VARCHAR(10),
    Department VARCHAR(50),
    Year INT,
    Email VARCHAR(100),
    Phone VARCHAR(15)
);

CREATE TABLE Courses (
    CourseID INT PRIMARY KEY AUTO_INCREMENT,
    CourseName VARCHAR(100),
    Faculty VARCHAR(100),
    Credits INT
);

CREATE TABLE Enrollments (
    EnrollmentID INT PRIMARY KEY AUTO_INCREMENT,
    StudentID INT,
    CourseID INT,
    Marks INT,
    Grade VARCHAR(2),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
);

INSERT INTO Students (Name, Gender, Department, Year, Email, Phone) VALUES
('Vaishnavi','Female','CSE',3,'vaishnavi@email.com','9876543210'),
('Rahul','Male','ECE',2,'rahul@email.com','9876500001'),
('Sneha','Female','IT',3,'sneha@email.com','9876500002'),
('Kiran','Male','CSE',4,'kiran@email.com','9876500003'),
('Anjali','Female','EEE',1,'anjali@email.com','9876500004');

INSERT INTO Courses (CourseName, Faculty, Credits) VALUES
('Python Programming','Dr. Kumar',4),
('Database Management Systems','Dr. Priya',3),
('Web Development','Dr. Ravi',4),
('Machine Learning','Dr. Meena',4);

INSERT INTO Enrollments (StudentID, CourseID, Marks, Grade) VALUES
(1,1,92,'A+'),
(1,2,88,'A'),
(2,2,75,'B'),
(3,3,81,'A'),
(4,4,95,'A+'),
(5,1,69,'C');

-- Sample Queries
SELECT * FROM Students;
SELECT Name, Department FROM Students WHERE Department='CSE';
SELECT * FROM Students ORDER BY Name;
SELECT Department, COUNT(*) AS TotalStudents FROM Students GROUP BY Department;

SELECT s.Name, c.CourseName, e.Marks, e.Grade
FROM Students s
JOIN Enrollments e ON s.StudentID = e.StudentID
JOIN Courses c ON c.CourseID = e.CourseID;

UPDATE Students SET Phone='9999999999' WHERE StudentID=1;
DELETE FROM Students WHERE StudentID=5;
